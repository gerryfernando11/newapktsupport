package rest.iconpln.model;

public class RestInteg {

}
